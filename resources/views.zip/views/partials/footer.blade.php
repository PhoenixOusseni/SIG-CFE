<footer class="footer-admin mt-auto footer-light">
    <div class="container-xl px-4">
        <div class="row">
            <div class="col-md-6 small">Copyright © Gestion de stock 2024</div>
            <div class="col-md-6 text-md-end small">
                <a href="javascript:;">Développé par Safreco</a>
            </div>
        </div>
    </div>
</footer>
